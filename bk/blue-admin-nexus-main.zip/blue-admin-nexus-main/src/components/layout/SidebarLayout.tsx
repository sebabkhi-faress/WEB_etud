
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Home,
  Layers,
  Briefcase,
  GraduationCap,
  CalendarDays,
  Layout,
  Settings,
  Menu,
  X,
  LogOut,
  User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useIsMobile } from '@/hooks/use-mobile';

interface SidebarItemProps {
  title: string;
  path: string;
  icon: React.ReactNode;
  isExpanded: boolean;
  isActive: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({
  title,
  path,
  icon,
  isExpanded,
  isActive
}) => {
  return (
    <Link
      to={path}
      className={`flex items-center px-4 py-3 my-1 rounded-lg transition-colors ${
        isActive
          ? 'bg-primary-600 text-white'
          : 'hover:bg-primary-100 text-gray-700 hover:text-primary-800'
      }`}
    >
      <div className="flex items-center">
        <span className="mr-3">{icon}</span>
        {isExpanded && <span className="font-medium">{title}</span>}
      </div>
    </Link>
  );
};

interface SidebarLayoutProps {
  children: React.ReactNode;
}

const SidebarLayout: React.FC<SidebarLayoutProps> = ({ children }) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { signOut, profile } = useAuth();
  const isMobile = useIsMobile();

  const toggleSidebar = () => {
    setIsExpanded(!isExpanded);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const sidebarItems = [
    {
      title: 'Dashboard',
      path: '/dashboard',
      icon: <Home size={20} />
    },
    {
      title: 'Formations',
      path: '/formations',
      icon: <GraduationCap size={20} />
    },
    {
      title: 'Levels',
      path: '/levels',
      icon: <Layers size={20} />
    },
    {
      title: 'Categories',
      path: '/categories',
      icon: <Briefcase size={20} />
    },
    {
      title: 'Semesters',
      path: '/semesters',
      icon: <CalendarDays size={20} />
    },
    {
      title: 'Units',
      path: '/units',
      icon: <Layout size={20} />
    },
    {
      title: 'Modules',
      path: '/modules',
      icon: <BookOpen size={20} />
    },
    {
      title: 'Sections',
      path: '/sections',
      icon: <Layout size={20} />
    },
    {
      title: 'Groups',
      path: '/groups',
      icon: <Layers size={20} />
    },
    {
      title: 'Profile',
      path: '/profile',
      icon: <User size={20} />
    },
    {
      title: 'Settings',
      path: '/settings',
      icon: <Settings size={20} />
    }
  ];

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const renderSidebar = () => (
    <div
      className={`bg-white border-r border-gray-200 flex flex-col h-full transition-all duration-300 ${
        isExpanded ? 'w-64' : 'w-16'
      }`}
    >
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        {isExpanded && (
          <Link to="/dashboard" className="text-xl font-bold text-primary-800">
            Admin Panel
          </Link>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleSidebar}
          className={!isExpanded ? 'mx-auto' : ''}
        >
          {isExpanded ? (
            <ChevronLeft size={20} />
          ) : (
            <ChevronRight size={20} />
          )}
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        {sidebarItems.map((item) => (
          <SidebarItem
            key={item.path}
            title={item.title}
            path={item.path}
            icon={item.icon}
            isExpanded={isExpanded}
            isActive={location.pathname === item.path}
          />
        ))}
      </div>

      <div className="p-4 border-t border-gray-200">
        <Button
          variant="ghost"
          className={`w-full justify-start text-gray-700 hover:text-red-600 hover:bg-red-50 ${
            !isExpanded && 'justify-center'
          }`}
          onClick={signOut}
        >
          <LogOut size={20} className="mr-2" />
          {isExpanded && <span>Sign Out</span>}
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-50">
      {isMobile ? (
        <>
          <div
            className={`fixed inset-0 bg-gray-800 bg-opacity-50 z-40 transition-opacity duration-300 ${
              isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
            onClick={closeMobileMenu}
          />
          <div
            className={`fixed inset-y-0 left-0 z-50 w-64 transition-transform duration-300 transform ${
              isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
            }`}
          >
            {renderSidebar()}
          </div>
        </>
      ) : (
        renderSidebar()
      )}

      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="bg-white shadow-sm p-4 flex justify-between items-center">
          {isMobile && (
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleMobileMenu}
              className="md:hidden"
            >
              <Menu size={20} />
            </Button>
          )}
          <div className="font-medium text-gray-800">
            {profile ? `Welcome, ${profile.firstname} ${profile.lastname}` : 'Welcome'}
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6 bg-gray-50">{children}</main>
      </div>
    </div>
  );
};

export default SidebarLayout;
