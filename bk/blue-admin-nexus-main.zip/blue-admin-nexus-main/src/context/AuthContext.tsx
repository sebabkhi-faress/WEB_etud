import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User as SupabaseUser } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { User } from '@/types/database.types';
import { userService, accountService } from '@/services/user.service';

interface AuthContextType {
  user: SupabaseUser | null;
  profile: User | null;
  account: { id: number, username: string } | null;
  isLoading: boolean;
  signIn: (username: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [profile, setProfile] = useState<User | null>(null);
  const [account, setAccount] = useState<{ id: number, username: string } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const checkSession = async () => {
      try {
        setIsLoading(true);
        
        // Check if we have a session in localStorage
        const storedAccount = localStorage.getItem('account');
        if (storedAccount) {
          const parsedAccount = JSON.parse(storedAccount);
          setAccount(parsedAccount);
          
          // Fetch user profile
          if (parsedAccount.id) {
            try {
              const userProfile = await userService.getByAccountId(parsedAccount.id);
              setProfile(userProfile);
            } catch (error) {
              console.error('Error fetching user profile:', error);
            }
          }
        }
      } catch (error) {
        console.error('Error checking session:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkSession();
    
    // Keep this for compatibility with Supabase Auth if needed later
    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null);
      }
    );

    return () => {
      if (authListener && authListener.subscription) {
        authListener.subscription.unsubscribe();
      }
    };
  }, []);

  const handleSignIn = async (username: string, password: string) => {
    try {
      setIsLoading(true);
      
      const accountData = await accountService.authenticate(username, password);
      
      if (!accountData) {
        toast({
          title: "Authentication error",
          description: "Invalid username or password",
          variant: "destructive",
        });
        return;
      }
      
      // Store account info in state and localStorage
      const accountInfo = { 
        id: accountData.id_account, 
        username: accountData.username 
      };
      
      setAccount(accountInfo);
      localStorage.setItem('account', JSON.stringify(accountInfo));
      
      // Fetch user profile
      if (accountData.id_account) {
        try {
          const userProfile = await userService.getByAccountId(accountData.id_account);
          setProfile(userProfile);
        } catch (error) {
          console.error('Error fetching user profile:', error);
        }
      }
      
      toast({
        title: "Success!",
        description: "You have successfully signed in.",
      });
      
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "An error occurred during sign in",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      setIsLoading(true);
      
      // Remove from localStorage
      localStorage.removeItem('account');
      
      // Clear state
      setAccount(null);
      setProfile(null);
      setUser(null);
      
      // Also sign out from Supabase Auth if it was used
      await supabase.auth.signOut();
      
      toast({
        title: "Signed out",
        description: "You have been successfully signed out.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "An error occurred during sign out",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    user,
    profile,
    account,
    isLoading,
    signIn: handleSignIn,
    signOut: handleSignOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
