
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  BookOpen, 
  Plus, 
  Search, 
  Edit, 
  Trash2,
  ArrowDown,
  ArrowUp 
} from 'lucide-react';
import SidebarLayout from '@/components/layout/SidebarLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Module, Unit } from '@/types/database.types';
import { moduleService, unitService } from '@/services/supabase.service';

const Modules = () => {
  const [modules, setModules] = useState<Module[]>([]);
  const [units, setUnits] = useState<Unit[]>([]);
  const [filteredModules, setFilteredModules] = useState<Module[]>([]);
  const [selectedModule, setSelectedModule] = useState<Module | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [sortField, setSortField] = useState<keyof Module>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  
  const { toast } = useToast();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const modulesData = await moduleService.getAll();
        const unitsData = await unitService.getAll();
        
        setModules(modulesData);
        setFilteredModules(modulesData);
        setUnits(unitsData);
      } catch (error) {
        console.error('Error fetching modules:', error);
        toast({
          title: 'Error',
          description: 'Failed to load modules. Please try again later.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [toast]);

  useEffect(() => {
    // Filter and sort modules when searchTerm or sort parameters change
    const filtered = modules.filter(module => 
      module.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      module.description?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    const sorted = [...filtered].sort((a, b) => {
      const fieldA = a[sortField] || '';
      const fieldB = b[sortField] || '';
      
      if (typeof fieldA === 'string' && typeof fieldB === 'string') {
        return sortDirection === 'asc'
          ? fieldA.localeCompare(fieldB)
          : fieldB.localeCompare(fieldA);
      } else if (typeof fieldA === 'number' && typeof fieldB === 'number') {
        return sortDirection === 'asc' ? fieldA - fieldB : fieldB - fieldA;
      }
      return 0;
    });
    
    setFilteredModules(sorted);
  }, [searchTerm, modules, sortField, sortDirection]);

  const handleSort = (field: keyof Module) => {
    setSortDirection(prevDirection => 
      sortField === field && prevDirection === 'asc' ? 'desc' : 'asc'
    );
    setSortField(field);
  };

  const handleDeleteClick = (module: Module) => {
    setSelectedModule(module);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!selectedModule) return;
    
    try {
      await moduleService.remove(selectedModule.id_module);
      
      // Update the local state to reflect the deletion
      setModules(prevModules => 
        prevModules.filter(m => m.id_module !== selectedModule.id_module)
      );
      
      toast({
        title: 'Success',
        description: `Module "${selectedModule.name}" was deleted successfully.`,
      });
    } catch (error) {
      console.error('Error deleting module:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete the module. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsDeleteDialogOpen(false);
      setSelectedModule(null);
    }
  };

  const getUnitName = (unitId: number) => {
    const unit = units.find(u => u.idunit === unitId);
    return unit ? unit.name : 'Unknown Unit';
  };

  const SortIcon = ({ field }: { field: keyof Module }) => {
    if (sortField !== field) return null;
    
    return sortDirection === 'asc' ? (
      <ArrowUp className="h-4 w-4 ml-1" />
    ) : (
      <ArrowDown className="h-4 w-4 ml-1" />
    );
  };

  return (
    <SidebarLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Modules</h1>
            <p className="text-muted-foreground">
              Manage teaching modules and their details
            </p>
          </div>
          <Link to="/modules/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" /> Add Module
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <BookOpen className="mr-2 h-5 w-5" /> Module List
            </CardTitle>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
              <Input
                placeholder="Search modules..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
              </div>
            ) : filteredModules.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {searchTerm ? 'No modules found matching your search.' : 'No modules added yet.'}
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead 
                        className="cursor-pointer"
                        onClick={() => handleSort('name')}
                      >
                        <div className="flex items-center">
                          Name
                          <SortIcon field="name" />
                        </div>
                      </TableHead>
                      <TableHead>Unit</TableHead>
                      <TableHead 
                        className="cursor-pointer"
                        onClick={() => handleSort('coefficient')}
                      >
                        <div className="flex items-center">
                          Coefficient
                          <SortIcon field="coefficient" />
                        </div>
                      </TableHead>
                      <TableHead 
                        className="cursor-pointer"
                        onClick={() => handleSort('hours')}
                      >
                        <div className="flex items-center">
                          Hours
                          <SortIcon field="hours" />
                        </div>
                      </TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredModules.map((module) => (
                      <TableRow key={module.id_module}>
                        <TableCell className="font-medium">{module.name}</TableCell>
                        <TableCell>{getUnitName(module.idunit)}</TableCell>
                        <TableCell>{module.coefficient || 'N/A'}</TableCell>
                        <TableCell>{module.hours || 'N/A'}</TableCell>
                        <TableCell className="text-right space-x-2">
                          <Link to={`/modules/edit/${module.id_module}`}>
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </Link>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleDeleteClick(module)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the module "{selectedModule?.name}"? 
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteConfirm}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SidebarLayout>
  );
};

export default Modules;
