
import { supabase } from '@/lib/supabase';
import { Account, User } from '@/types/database.types';
import { getAll, getById, create, update, remove } from './base.service';

export const userService = {
  getAll: () => getAll<User>('user'),
  getById: (id: number) => getById<User>('user', 'id_user', id),
  create: (user: Partial<User>) => create<User>('user', user),
  update: (id: number, user: Partial<User>) => update<User>('user', 'id_user', id, user),
  remove: (id: number) => remove('user', 'id_user', id),
  getByAccountId: async (accountId: number): Promise<User | null> => {
    const { data, error } = await supabase
      .from('user')
      .select('*')
      .eq('id_account', accountId)
      .single();
      
    if (error) {
      if (error.code === 'PGRST116') {
        return null;
      }
      console.error(`Error fetching user for account ${accountId}:`, error);
      throw error;
    }
    
    return data as User;
  }
};

export const accountService = {
  getAll: () => getAll<Account>('account'),
  getById: (id: number) => getById<Account>('account', 'id_account', id),
  create: (account: Partial<Account>) => create<Account>('account', account),
  update: (id: number, account: Partial<Account>) => update<Account>('account', 'id_account', id, account),
  remove: (id: number) => remove('account', 'id_account', id),
  getByUsername: async (username: string): Promise<Account | null> => {
    const { data, error } = await supabase
      .from('account')
      .select('*')
      .eq('username', username)
      .single();
      
    if (error) {
      if (error.code === 'PGRST116') {
        return null;
      }
      console.error(`Error fetching account with username ${username}:`, error);
      throw error;
    }
    
    return data as Account;
  },
  authenticate: async (username: string, password: string): Promise<Account | null> => {
    const { data, error } = await supabase
      .from('account')
      .select('*')
      .eq('username', username)
      .eq('password', password)
      .single();
      
    if (error) {
      if (error.code === 'PGRST116') {
        return null;
      }
      console.error('Authentication error:', error);
      throw error;
    }
    
    return data as Account;
  }
};
