
import { Formation, Level, Category, Semester, Unit, Module, Section, Group } from '@/types/database.types';
import { getAll, getById, create, update, remove } from './base.service';

export const formationService = {
  getAll: () => getAll<Formation>('formation'),
  getById: (id: number) => getById<Formation>('formation', 'idformation', id),
  create: (formation: Partial<Formation>) => create<Formation>('formation', formation),
  update: (id: number, formation: Partial<Formation>) => update<Formation>('formation', 'idformation', id, formation),
  remove: (id: number) => remove('formation', 'idformation', id)
};

export const levelService = {
  getAll: () => getAll<Level>('level'),
  getById: (id: number) => getById<Level>('level', 'idlevel', id),
  create: (level: Partial<Level>) => create<Level>('level', level),
  update: (id: number, level: Partial<Level>) => update<Level>('level', 'idlevel', id, level),
  remove: (id: number) => remove('level', 'idlevel', id),
  getByFormation: async (formationId: number): Promise<Level[]> => {
    const { data, error } = await supabase
      .from('level')
      .select('*')
      .eq('idformation', formationId);
      
    if (error) {
      console.error(`Error fetching levels for formation ${formationId}:`, error);
      throw error;
    }
    
    return data as Level[];
  }
};

export const categoryService = {
  getAll: () => getAll<Category>('category'),
  getById: (id: number) => getById<Category>('category', 'idspecialty', id),
  create: (category: Partial<Category>) => create<Category>('category', category),
  update: (id: number, category: Partial<Category>) => update<Category>('category', 'idspecialty', id, category),
  remove: (id: number) => remove('category', 'idspecialty', id),
  getByLevel: async (levelId: number): Promise<Category[]> => {
    const { data, error } = await supabase
      .from('category')
      .select('*')
      .eq('idlevel', levelId);
      
    if (error) {
      console.error(`Error fetching categories for level ${levelId}:`, error);
      throw error;
    }
    
    return data as Category[];
  }
};
