
import { createClient } from '@supabase/supabase-js';

// Use the Supabase URL and anon key provided by the user
const supabaseUrl = "https://nikqhdzgmktkryrqtgsv.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5pa3FoZHpnbWt0a3J5cnF0Z3N2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQ4MjEyNjcsImV4cCI6MjA2MDM5NzI2N30.GKrAm7RLmGcWm4tONLF0tR8RQrGANm1mnn59OsKphPc";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
