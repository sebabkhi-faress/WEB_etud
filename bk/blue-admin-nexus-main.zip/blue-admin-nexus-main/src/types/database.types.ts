export interface Account {
  id_account: number;
  username: string;
  password: string;
  created_at?: string;
  updated_at?: string;
}

export interface User {
  id_user: number;
  id_account: number;
  firstname: string;
  lastname: string;
  phone?: string;
  birthdate?: string;
  address?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Formation {
  idformation: number;
  name: string;
  description?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Level {
  idlevel: number;
  idformation: number;
  name: string;
  description?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Category {
  idspecialty: number;
  idlevel: number;
  name: string;
  description?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Semester {
  idsemester: number;
  idspecialty: number;
  name: string;
  start_date?: string;
  end_date?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Unit {
  idunit: number;
  idsemester: number;
  name: string;
  description?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Module {
  id_module: number;
  idunit: number;
  name: string;
  description?: string;
  coefficient?: number;
  hours?: number;
  created_at?: string;
  updated_at?: string;
}

export interface Section {
  idsection: number;
  idsemester: number;
  name: string;
  description?: string;
  created_at?: string;
  updated_at?: string;
}

export interface Group {
  idgroup: number;
  idsection: number;
  name: string;
  description?: string;
  created_at?: string;
  updated_at?: string;
}
